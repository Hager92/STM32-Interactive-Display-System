
#ifndef MSTK_CONFIG_H_
#define MSTK_CONFIG_H_

#define MSTK_CLK_SOURCE   MSTK_AHB


#endif /* MSTK_CONFIG_H_ */
